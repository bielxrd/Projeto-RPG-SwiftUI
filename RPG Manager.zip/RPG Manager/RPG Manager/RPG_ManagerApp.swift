//
//  RPG_ManagerApp.swift
//  RPG Manager
//
//  Created by Student06 on 19/09/23.
//

import SwiftUI

@main
struct RPG_ManagerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
