//
//  ReadData3.swift
//  RPG Manager
//
//  Created by Student06 on 28/09/23.
//

import SwiftUI

struct ReadData3: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ReadData3_Previews: PreviewProvider {
    static var previews: some View {
        ReadData3()
    }
}
