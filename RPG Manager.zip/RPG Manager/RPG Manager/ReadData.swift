//
//  ReadData.swift
//  RPG Manager
//
//  Created by Student06 on 28/09/23.
//

import SwiftUI

struct ReadData: View {
  //  @StateObject var racas = ViewModelRPGDNDRACES()
    
    var body: some View {
        VStack{
            
        }
        
        
    }
}
struct ReadData_Preview: PreviewProvider {
    static var previews: some View {
      //  ReadData(racas: racesRPG(count:2,next:"",previous: "",results: [resultsRaces(name: "Teste", slug: "", desc: "", asiDesc: "", asi: [AbilityScoreIncrease(attributes:["Const,Charisma"] , value: 2)], age: "", alignment: "", size: "", speed: Speed(walk: 9), speedDesc: "", languages: "", vision: "", traits: "", subraces: [Subrace(name:"",slug: "",desc: "",asi: [AbilityScoreIncrease(attributes: [""], value: 0)],asiDesc: "",documentSlug: "",documentTitle: "",documentURL: ""  )] )]))
        ReadData()
    }
}


