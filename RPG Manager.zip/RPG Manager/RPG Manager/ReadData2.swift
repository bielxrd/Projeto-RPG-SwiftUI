//
//  ReadData2.swift
//  RPG Manager
//
//  Created by Student06 on 28/09/23.
//

import SwiftUI

struct ReadData2: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ReadData2_Previews: PreviewProvider {
    static var previews: some View {
        ReadData2()
    }
}
